
from datetime import datetime

def calculate_worked_hours(in_time_str, out_time_str):
    
    in_time = datetime.strptime(in_time_str, '%H:%M')
    out_time = datetime.strptime(out_time_str, '%H:%M')
    duration = out_time - in_time
    return round(duration.total_seconds() / 3600, 2)

def get_attendance_status(worked_hours):
   
    if worked_hours >= 6:
        return 'Present'
    elif 3 <= worked_hours < 6:
        return 'Half Day'
    else:
        return 'Absent'
