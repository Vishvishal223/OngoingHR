from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, time

from app import db

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.Text, nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'admin', 'employee'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    profile = db.relationship('EmployeeProfile', backref='user', uselist=False)


class EmployeeProfile(db.Model):
    __tablename__ = 'employee_profiles'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)
    department = db.Column(db.String(50))
    dob = db.Column(db.Date)
    joining_date = db.Column(db.Date)
    phone = db.Column(db.String(15))
    address = db.Column(db.Text)
    salary = db.Column(db.Numeric(10, 2))


class Attendance(db.Model):
    __tablename__ = 'attendance'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    in_time = db.Column(db.Time)
    out_time = db.Column(db.Time)
    worked_hours = db.Column(db.Float)  # e.g., 6.5
    status = db.Column(db.String(20))  # Present, Half Day, Absent
    leave_linked = db.Column(db.Boolean, default=False)


class Leave(db.Model):
    __tablename__ = 'leaves'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    from_date = db.Column(db.Date, nullable=False)
    to_date = db.Column(db.Date, nullable=False)
    leave_type = db.Column(db.String(20))  # 'CL', 'ML'
    reason = db.Column(db.Text)
    status = db.Column(db.String(20), default='Pending')  # Approved, Rejected, Pending
    lop_flag = db.Column(db.Boolean, default=False)
    lop_days = db.Column(db.Integer, default=0)
    applied_at = db.Column(db.DateTime, default=datetime.utcnow)


class LeaveBalance(db.Model):
    __tablename__ = 'leave_balances'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    casual_used = db.Column(db.Integer, default=0)
    medical_used = db.Column(db.Integer, default=0)


class Task(db.Model):
    __tablename__ = 'tasks'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    assigned_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    assigned_to = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    priority = db.Column(db.String(20))  # Low, Medium, High
    status = db.Column(db.String(20), default='Pending')  # In Progress, Completed
    due_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class TaskComment(db.Model):
    __tablename__ = 'task_comments'

    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Feedback(db.Model):
    __tablename__ = 'feedback'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Announcement(db.Model):
    __tablename__ = 'announcements'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    content = db.Column(db.Text)
    posted_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    posted_at = db.Column(db.DateTime, default=datetime.utcnow)


class Payslip(db.Model):
    __tablename__ = 'payslips'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    month = db.Column(db.String(10), nullable=False)
    base_salary = db.Column(db.Numeric(10, 2))
    lop_days_attendance = db.Column(db.Integer, default=0)
    lop_days_leave = db.Column(db.Integer, default=0)
    total_lop = db.Column(db.Integer, default=0)
    final_salary = db.Column(db.Numeric(10, 2))
    pdf_link = db.Column(db.String(255))
    uploaded_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)


class HRPolicy(db.Model):
    __tablename__ = 'hr_policies'

    id = db.Column(db.Integer, primary_key=True)
    policy_type = db.Column(db.String(50))  # e.g. 'CL_LIMIT'
    value = db.Column(db.Integer)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
