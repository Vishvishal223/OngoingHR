from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from app import db
from app.models import Attendance, Leave, User
import jwt
import os
from functools import wraps

attendance_bp = Blueprint('attendance', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)
    return decorated

def calculate_hours(in_time_str, out_time_str):
    fmt = '%H:%M'
    in_time = datetime.strptime(in_time_str, fmt)
    out_time = datetime.strptime(out_time_str, fmt)
    duration = out_time - in_time
    hours = duration.total_seconds() / 3600
    return round(hours, 2)

@attendance_bp.route('/mark', methods=['POST'])
@token_required
def mark_attendance(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can mark attendance'}), 403

    data = request.get_json()
    date_str = data.get('date') 
    in_time = data.get('in_time')  
    out_time = data.get('out_time') 

    if not (date_str and in_time and out_time):
        return jsonify({'error': 'Incomplete data'}), 400

    worked_hours = calculate_hours(in_time, out_time)

   
    if worked_hours >= 6:
        status = 'Present'
    elif 3 <= worked_hours < 6:
        status = 'Half Day'
    else:
        status = 'Absent'

    attendance_date = datetime.strptime(date_str, '%Y-%m-%d').date()

   
    record = Attendance.query.filter_by(user_id=current_user.id, date=attendance_date).first()
    if not record:
        record = Attendance(user_id=current_user.id, date=attendance_date)

    record.in_time = datetime.strptime(in_time, '%H:%M').time()
    record.out_time = datetime.strptime(out_time, '%H:%M').time()
    record.worked_hours = worked_hours
    record.status = status

    # Leave link check
    leave_applied = Leave.query.filter(
        Leave.user_id == current_user.id,
        Leave.from_date <= attendance_date,
        Leave.to_date >= attendance_date,
        Leave.status == 'Approved'
    ).first()

    record.leave_linked = bool(leave_applied)

    db.session.add(record)
    db.session.commit()

    return jsonify({
        'message': 'Attendance recorded',
        'status': status,
        'worked_hours': worked_hours,
        'leave_linked': record.leave_linked
    }), 200

@attendance_bp.route('/history', methods=['GET'])
@token_required
def get_attendance_history(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can view this'}), 403

    records = Attendance.query.filter_by(user_id=current_user.id).order_by(Attendance.date.desc()).all()
    history = []
    for r in records:
        history.append({
            'date': r.date.strftime('%Y-%m-%d'),
            'in_time': r.in_time.strftime('%H:%M') if r.in_time else None,
            'out_time': r.out_time.strftime('%H:%M') if r.out_time else None,
            'worked_hours': r.worked_hours,
            'status': r.status,
            'leave_linked': r.leave_linked
        })

    return jsonify({'attendance': history}), 200

@attendance_bp.route('/admin/report', methods=['GET'])
@token_required
def admin_attendance_report(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can access this'}), 403

    user_id = request.args.get('user_id')
    date = request.args.get('date')  

    query = Attendance.query
    if user_id:
        query = query.filter_by(user_id=user_id)
    if date:
        date_obj = datetime.strptime(date, '%Y-%m-%d').date()
        query = query.filter_by(date=date_obj)

    records = query.order_by(Attendance.date.desc()).all()
    result = []
    for r in records:
        result.append({
            'user_id': r.user_id,
            'date': r.date.strftime('%Y-%m-%d'),
            'in_time': r.in_time.strftime('%H:%M') if r.in_time else None,
            'out_time': r.out_time.strftime('%H:%M') if r.out_time else None,
            'worked_hours': r.worked_hours,
            'status': r.status,
            'leave_linked': r.leave_linked
        })

    return jsonify({'records': result}), 200
