from flask import Blueprint, request, jsonify
from app import db
from app.models import HRPolicy, User
import jwt
import os
from functools import wraps

policy_bp = Blueprint('policy', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)
    return decorated

@policy_bp.route('/update', methods=['POST'])
@token_required
def update_policy(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can set policies'}), 403

    data = request.get_json()
    policy_type = data.get('policy_type')  
    value = data.get('value')

    if not policy_type or value is None:
        return jsonify({'error': 'Invalid policy data'}), 400

    policy = HRPolicy.query.filter_by(policy_type=policy_type).first()
    if not policy:
        policy = HRPolicy(policy_type=policy_type, value=value)
    else:
        policy.value = value

    db.session.add(policy)
    db.session.commit()

    return jsonify({'message': f'Policy {policy_type} set to {value}'}), 200

@policy_bp.route('/all', methods=['GET'])
@token_required
def get_policies(current_user):
    policies = HRPolicy.query.all()
    result = {}
    for p in policies:
        result[p.policy_type] = p.value

    return jsonify({'policies': result}), 200
