from flask import Blueprint, request, jsonify
from datetime import datetime,timedelta
from app import db
from app.models import Payslip, Leave, User, EmployeeProfile
import jwt
import os
from functools import wraps

payslip_bp = Blueprint('payslip', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)
    return decorated


@payslip_bp.route('/generate', methods=['POST'])
@token_required
def generate_payslip(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can generate payslips'}), 403

    data = request.get_json()
    user_id = data.get('user_id')
    month = data.get('month')  

    if not user_id or not month:
        return jsonify({'error': 'user_id and month are required'}), 400

    user = User.query.get(user_id)
    profile = EmployeeProfile.query.filter_by(user_id=user_id).first()

    if not user or not profile:
        return jsonify({'error': 'Employee not found'}), 404

    base_salary = float(profile.salary)
    year, month_num = map(int, month.split('-'))

    
    lop_leaves = Leave.query.filter(
        Leave.user_id == user_id,
        Leave.status == 'Approved',
        Leave.lop_flag == True,
        Leave.from_date >= datetime(year, month_num, 1),
        Leave.to_date <= datetime(year, month_num, 28) + timedelta(days=4)  
    ).all()

    total_lop = sum(l.lop_days for l in lop_leaves)
    per_day_salary = base_salary / 30
    lop_deduction = round(total_lop * per_day_salary, 2)
    net_salary = round(base_salary - lop_deduction, 2)

    
    existing = Payslip.query.filter_by(user_id=user_id, month=month).first()
    if existing:
        return jsonify({'error': 'Payslip for this month already exists'}), 409

    slip = Payslip(
    user_id=user_id,
    month=month,
    base_salary=base_salary,
    lop_days_leave=total_lop,
    total_lop=total_lop,
    final_salary=net_salary,
    uploaded_by=current_user.id
    )


    db.session.add(slip)
    db.session.commit()

    return jsonify({'message': 'Payslip generated successfully'}), 201

@payslip_bp.route('/my', methods=['GET'])
@token_required
def get_my_payslips(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can view their payslips'}), 403

    slips = Payslip.query.filter_by(user_id=current_user.id).order_by(Payslip.month.desc()).all()
    result = []
    for s in slips:
        result.append({
            'month': s.month,
            'base_salary': s.base_salary,
            'lop_days': s.total_lop,
            'net_salary': s.final_salary
        })

    return jsonify({'payslips': result}), 200

@payslip_bp.route('/employee/<int:user_id>', methods=['GET'])
@token_required
def get_employee_payslips(current_user, user_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can view payslips of employees'}), 403

    slips = Payslip.query.filter_by(user_id=user_id).order_by(Payslip.month.desc()).all()
    result = []
    for s in slips:
        result.append({
            'month': s.month,
            'base_salary': s.base_salary,
            'lop_days': s.total_lop,
            'net_salary': s.final_salary
        })

    return jsonify({'payslips': result}), 200
