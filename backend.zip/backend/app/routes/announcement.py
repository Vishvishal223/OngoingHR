from flask import Blueprint, request, jsonify
from datetime import datetime
from app import db
from app.models import Announcement, User
import jwt
import os
from functools import wraps

announcement_bp = Blueprint('announcement', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)
    return decorated

@announcement_bp.route('/create', methods=['POST'])
@token_required
def create_announcement(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can post announcements'}), 403

    data = request.get_json()
    title = data.get('title')
    content = data.get('content')

    if not title or not content:
        return jsonify({'error': 'Title and content are required'}), 400

    new_announcement = Announcement(
        title=title,
        content=content,
        posted_by=current_user.name
    )

    db.session.add(new_announcement)
    db.session.commit()

    return jsonify({'message': 'Announcement created successfully'}), 201

@announcement_bp.route('/all', methods=['GET'])
@token_required
def view_announcements(current_user):
    announcements = Announcement.query.order_by(Announcement.posted_at.desc()).all()
    result = []
    for a in announcements:
        result.append({
            'id': a.id,
            'title': a.title,
            'content': a.content,
            'posted_by': a.posted_by,
            'posted_at': a.posted_at.strftime('%Y-%m-%d %H:%M')
        })

    return jsonify({'announcements': result}), 200
