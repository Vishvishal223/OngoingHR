from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from app import db
from app.models import Leave, LeaveBalance, HRPolicy, User
import jwt
import os
from functools import wraps

leave_bp = Blueprint('leave', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)
    return decorated

def get_policy_limits():
    policies = HRPolicy.query.all()
    limits = {}
    for policy in policies:
        limits[policy.policy_type] = policy.value
    return limits

@leave_bp.route('/apply', methods=['POST'])
@token_required
def apply_leave(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can apply for leave'}), 403

    data = request.get_json()
    from_date = datetime.strptime(data.get('from_date'), '%Y-%m-%d').date()
    to_date = datetime.strptime(data.get('to_date'), '%Y-%m-%d').date()
    leave_type = data.get('leave_type')  # 'CL', 'ML'
    reason = data.get('reason', '')

    if from_date > to_date:
        return jsonify({'error': 'Invalid date range'}), 400

    num_days = (to_date - from_date).days + 1

    year = from_date.year
    balance = LeaveBalance.query.filter_by(user_id=current_user.id, year=year).first()
    if not balance:
        balance = LeaveBalance(
            user_id=current_user.id,
            year=year,
            casual_used=0,
            medical_used=0
        )
        db.session.add(balance)
        db.session.commit()


    limits = get_policy_limits()
    allowed = limits.get(f"{leave_type}_LIMIT", 0)

    used = balance.casual_used if leave_type == 'CL' else balance.medical_used
    will_exceed = used + num_days > allowed
    lop_days = (used + num_days - allowed) if will_exceed else 0

    new_leave = Leave(
        user_id=current_user.id,
        from_date=from_date,
        to_date=to_date,
        leave_type=leave_type,
        reason=reason,
        status='Pending',
        lop_flag=will_exceed,
        lop_days=lop_days
    )

    db.session.add(new_leave)
    db.session.commit()

    return jsonify({
        'message': 'Leave request submitted',
        'lop_flag': will_exceed,
        'lop_days': lop_days
    }), 201

@leave_bp.route('/approve/<int:leave_id>', methods=['PUT'])
@token_required
def approve_leave(current_user, leave_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can approve/reject leaves'}), 403

    data = request.get_json()
    action = data.get('action')  # 'approve' or 'reject'

    leave = Leave.query.get(leave_id)
    if not leave:
        return jsonify({'error': 'Leave not found'}), 404

    if leave.status != 'Pending':
        return jsonify({'error': 'Leave already processed'}), 400

    if action == 'approve':
        leave.status = 'Approved'
        year = leave.from_date.year
        balance = LeaveBalance.query.filter_by(user_id=leave.user_id, year=year).first()
        if not balance:
            balance = LeaveBalance(user_id=leave.user_id, year=year)

        used_days = (leave.to_date - leave.from_date).days + 1
        if leave.leave_type == 'CL':
            balance.casual_used += used_days
        else:
            balance.medical_used += used_days

        db.session.add(balance)

    elif action == 'reject':
        leave.status = 'Rejected'
    else:
        return jsonify({'error': 'Invalid action'}), 400

    db.session.commit()
    return jsonify({'message': f'Leave {leave.status.lower()} successfully'}), 200

@leave_bp.route('/history', methods=['GET'])
@token_required
def my_leave_history(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can view their leave history'}), 403

    records = Leave.query.filter_by(user_id=current_user.id).order_by(Leave.from_date.desc()).all()
    result = []
    for r in records:
        result.append({
            'from_date': r.from_date.strftime('%Y-%m-%d'),
            'to_date': r.to_date.strftime('%Y-%m-%d'),
            'leave_type': r.leave_type,
            'status': r.status,
            'lop_flag': r.lop_flag,
            'lop_days': r.lop_days,
            'reason': r.reason
        })

    return jsonify({'leaves': result}), 200

@leave_bp.route('/all', methods=['GET'])
@token_required
def get_all_leaves(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can view all leave requests'}), 403

    records = Leave.query.order_by(Leave.from_date.desc()).all()
    result = []
    for r in records:
        user = User.query.get(r.user_id)
        result.append({
            'leave_id': r.id,
            'employee': user.name if user else '',
            'from_date': r.from_date.strftime('%Y-%m-%d'),
            'to_date': r.to_date.strftime('%Y-%m-%d'),
            'leave_type': r.leave_type,
            'status': r.status,
            'lop_flag': r.lop_flag,
            'lop_days': r.lop_days,
            'reason': r.reason
        })

    return jsonify({'leaves': result}), 200
