from flask import Blueprint, request, jsonify
from app import db
from app.models import User, EmployeeProfile
import jwt
import os
from functools import wraps

employee_bp = Blueprint('employee', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None

        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except Exception as e:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)

    return decorated

@employee_bp.route('/me', methods=['GET'])
@token_required
def get_profile(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Access denied'}), 403

    profile = EmployeeProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        return jsonify({'error': 'Profile not found'}), 404

    return jsonify({
        'user': {
            'id': current_user.id,
            'name': current_user.name,
            'email': current_user.email,
            'role': current_user.role,
        },
        'profile': {
            'department': profile.department,
            'dob': profile.dob.strftime('%Y-%m-%d') if profile.dob else None,
            'joining_date': profile.joining_date.strftime('%Y-%m-%d') if profile.joining_date else None,
            'phone': profile.phone,
            'address': profile.address,
            'salary': float(profile.salary)
        }
    }), 200

@employee_bp.route('/update/<int:user_id>', methods=['PUT'])
@token_required
def update_profile(current_user, user_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Access denied'}), 403

    data = request.get_json()

    profile = EmployeeProfile.query.filter_by(user_id=user_id).first()
    if not profile:
        profile = EmployeeProfile(user_id=user_id)

    profile.department = data.get('department')
    profile.dob = data.get('dob')
    profile.joining_date = data.get('joining_date')
    profile.phone = data.get('phone')
    profile.address = data.get('address')
    profile.salary = data.get('salary')

    db.session.add(profile)
    db.session.commit()

    return jsonify({'message': 'Employee profile updated successfully'}), 200

@employee_bp.route('/all', methods=['GET'])
@token_required
def get_all_employees(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Access denied'}), 403

    users = User.query.filter_by(role='employee').all()
    employee_data = []

    for user in users:
        profile = EmployeeProfile.query.filter_by(user_id=user.id).first()
        employee_data.append({
            'id': user.id,
            'name': user.name,
            'email': user.email,
            'department': profile.department if profile else None,
            'joining_date': profile.joining_date.strftime('%Y-%m-%d') if profile and profile.joining_date else None
        })

    return jsonify({'employees': employee_data}), 200
