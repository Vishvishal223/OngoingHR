from flask import Blueprint, request, jsonify
from datetime import datetime
from app import db
from app.models import Task, User
import jwt
import os
from functools import wraps

task_bp = Blueprint('tasks', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)
    return decorated

@task_bp.route('/assign', methods=['POST'])
@token_required
def assign_task(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can assign tasks'}), 403

    data = request.get_json()
    title = data.get('title')
    description = data.get('description')
    assigned_to = data.get('assigned_to')  
    priority = data.get('priority', 'Medium')  
    due_date = data.get('due_date')  

    if not title or not assigned_to:
        return jsonify({'error': 'Missing title or assignee'}), 400

    task = Task(
        title=title,
        description=description,
        assigned_by=current_user.id,
        assigned_to=assigned_to,
        priority=priority,
        due_date=datetime.strptime(due_date, '%Y-%m-%d') if due_date else None
    )

    db.session.add(task)
    db.session.commit()

    return jsonify({'message': 'Task assigned successfully'}), 201


@task_bp.route('/my', methods=['GET'])
@token_required
def get_my_tasks(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can view their tasks'}), 403

    tasks = Task.query.filter_by(assigned_to=current_user.id).order_by(Task.created_at.desc()).all()
    result = []
    for t in tasks:
        result.append({
            'id': t.id,
            'title': t.title,
            'description': t.description,
            'priority': t.priority,
            'status': t.status,
            'due_date': t.due_date.strftime('%Y-%m-%d') if t.due_date else None,
            'created_at': t.created_at.strftime('%Y-%m-%d')
        })

    return jsonify({'tasks': result}), 200


@task_bp.route('/update/<int:task_id>', methods=['PUT'])
@token_required
def update_task_status(current_user, task_id):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can update tasks'}), 403

    task = Task.query.get(task_id)
    if not task or task.assigned_to != current_user.id:
        return jsonify({'error': 'Task not found or unauthorized'}), 404

    data = request.get_json()
    new_status = data.get('status')  # In Progress, Completed, Pending

    task.status = new_status
    db.session.commit()

    return jsonify({'message': f'Task status updated to {new_status}'}), 200

@task_bp.route('/all', methods=['GET'])
@token_required
def view_all_tasks(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can view all tasks'}), 403

    tasks = Task.query.order_by(Task.created_at.desc()).all()
    result = []
    for t in tasks:
        assignee = User.query.get(t.assigned_to)
        result.append({
            'id': t.id,
            'title': t.title,
            'assigned_to': assignee.name if assignee else 'Unknown',
            'priority': t.priority,
            'status': t.status,
            'due_date': t.due_date.strftime('%Y-%m-%d') if t.due_date else None,
            'created_at': t.created_at.strftime('%Y-%m-%d')
        })

    return jsonify({'tasks': result}), 200
