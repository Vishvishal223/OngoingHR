from flask import Blueprint, request, jsonify
from datetime import datetime
from app import db
from app.models import Feedback, User
import jwt
import os
from functools import wraps

feedback_bp = Blueprint('feedback', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, os.getenv('SECRET_KEY'), algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
        except:
            return jsonify({'error': 'Invalid token'}), 401

        return f(current_user, *args, **kwargs)
    return decorated

@feedback_bp.route('/submit', methods=['POST'])
@token_required
def submit_feedback(current_user):
    if current_user.role != 'employee':
        return jsonify({'error': 'Only employees can submit feedback'}), 403

    data = request.get_json()
    message = data.get('message')

    if not message:
        return jsonify({'error': 'Message cannot be empty'}), 400

    feedback = Feedback(user_id=current_user.id, message=message)
    db.session.add(feedback)
    db.session.commit()

    return jsonify({'message': 'Feedback submitted successfully'}), 201

@feedback_bp.route('/all', methods=['GET'])
@token_required
def view_feedback(current_user):
    if current_user.role != 'admin':
        return jsonify({'error': 'Only admin can view feedback'}), 403

    feedback_list = Feedback.query.order_by(Feedback.created_at.desc()).all()
    result = []
    for fb in feedback_list:
        user = User.query.get(fb.user_id)
        result.append({
            'employee': user.name if user else 'Unknown',
            'email': user.email if user else '',
            'message': fb.message,
            'submitted_at': fb.created_at.strftime('%Y-%m-%d %H:%M')
        })

    return jsonify({'feedbacks': result}), 200
